// 
// Copyright (c) 2007-2009 Bo Morgan.
// All rights reserved.
// 
// Author: Bo Morgan
// 
// Permission to use, copy, modify and distribute this software and its
// documentation is hereby granted, provided that both the copyright
// notice and this permission notice appear in all copies of the
// software, derivative works or modified versions, and any portions
// thereof, and that both notices appear in supporting documentation.
// 
// BO MORGAN ALLOWS FREE USE OF THIS SOFTWARE IN ITS "AS IS" CONDITION.
// BO MORGAN DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY DAMAGES
// WHATSOEVER RESULTING FROM THE USE OF THIS SOFTWARE.
// 
// Bo Morgan requests users of this software to return to bo@mit.edu any
// improvements or extensions that they make and grant Bo Morgan the
// rights to redistribute these changes.
// 

#include "funk2.h"

void f2dynamicmemory__init_and_alloc(f2dynamicmemory_t* this, f2size_t byte_num) {
  this->byte_num = byte_num;
  this->ptr      = to_ptr(malloc(byte_num));
  if (from_ptr(this->ptr) == NULL) {
    perror("malloc");
    exit(-1);
  }
}

void f2dynamicmemory__destroy_and_free(f2dynamicmemory_t* this) {
  free(from_ptr(this->ptr));
  this->byte_num = 0;
  this->ptr      = to_ptr(NULL);
}

void f2dynamicmemory__realloc(f2dynamicmemory_t* new_memory, f2dynamicmemory_t* old_memory, f2size_t byte_num) {
  new_memory->ptr = to_ptr(realloc(from_ptr(old_memory->ptr), byte_num));
  if (from_ptr(new_memory->ptr) == NULL) {
    perror("realloc");
    exit(-1);
  }
  new_memory->byte_num = byte_num;
}


