?package(funk2):needs="text" section="Applications/Science"\
  title="funk2" command="/usr/bin/funk2"
