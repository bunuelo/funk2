// 
// Copyright (c) 2007-2009 Bo Morgan.
// All rights reserved.
// 
// Author: Bo Morgan
// 
// Permission to use, copy, modify and distribute this software and its
// documentation is hereby granted, provided that both the copyright
// notice and this permission notice appear in all copies of the
// software, derivative works or modified versions, and any portions
// thereof, and that both notices appear in supporting documentation.
// 
// BO MORGAN ALLOWS FREE USE OF THIS SOFTWARE IN ITS "AS IS" CONDITION.
// BO MORGAN DISCLAIMS ANY LIABILITY OF ANY KIND FOR ANY DAMAGES
// WHATSOEVER RESULTING FROM THE USE OF THIS SOFTWARE.
// 
// Bo Morgan requests users of this software to return to bo@mit.edu any
// improvements or extensions that they make and grant Bo Morgan the
// rights to redistribute these changes.
// 

#include <signal.h>
#include "f2_signal.h"

boolean_t __received_signal__sigint     = 0;
boolean_t __received_segmentation_fault = 0;

void f2__receive_signal(int sig) {
  switch(sig) {
  case SIGINT:
    printf ("\nsignal note: received ctrl-c\n"); fflush(stdout);
    __received_signal__sigint = 1;
    print_gc_stats();
    //memory_test();
    exit(f2__repl(initial_cause(), nil)); // these thread pointers might need to be valid
    break;
  case SIGSEGV:
    printf ("\nsignal note: received segmentation fault\n"); fflush(stdout);
    __received_segmentation_fault = 1;
    f2__print_threads_stacks();
    print_gc_stats();
    //memory_test();
    exit(f2__repl(initial_cause(), nil)); // these thread pointers might need to be valid
    break;
  default:
    printf ("\nsignal warning: received unknown signal (%d)\n", sig);
    //signal(sig, SIG_DFL);
    break;
  }
}

void f2__signal__reinitialize_globalvars() {
  //f2ptr cause =
  f2_signal_c__cause__new(initial_cause());
  
}

void f2__signal__initialize() {
  //f2ptr cause =
  f2_signal_c__cause__new(initial_cause());
  
  f2__signal__reinitialize_globalvars();
  
  //signal(SIGINT,  f2__receive_signal);
  //signal(SIGSEGV, f2__receive_signal);
}

