# Defaults for funk2 initscript
# sourced by /etc/init.d/funk2
# installed at /etc/default/funk2 by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
