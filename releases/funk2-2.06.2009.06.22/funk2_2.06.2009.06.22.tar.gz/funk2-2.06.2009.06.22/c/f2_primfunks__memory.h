#ifndef F2__PRIMFUNKS_MEMORY__H
#define F2__PRIMFUNKS_MEMORY__H

#include "f2_primfunks.h"
#include "f2_primobject__boolean.h"
#include "f2_primobject__char_pointer.h"

void f2__primfunks__memory__initialize();

#endif // F2__PRIMFUNKS_MEMORY__H
